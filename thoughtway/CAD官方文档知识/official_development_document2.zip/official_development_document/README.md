# CAD2021 CHM Local Retrieval System

本目录用于把 `acad_aag.chm` 与 `acadauto.chm` 转成一套面向智能体的本地检索体系。

当前目标只聚焦与本项目强相关的主题：

- 施工图自动化
- 打印
- 编目录
- 插图签
- pywin32 操作 CAD2021

默认不把 3D、渲染、材质、低频事件系统等内容作为主入口。

## 主入口

优先从以下层开始查：

1. `04_task_cards/`
   `04_task_cards/task_index.json` 是结构化主索引
2. `03_core_symbols/`
3. `05_pywin32_bridge/`
4. `06_on_demand_index/`
5. `02_manifest/page_manifest.jsonl`

第二轮补充后，`03_core_symbols/` 现在还应优先命中：

- `system_variables/`
- `types_and_variants/`

## 快速使用

```powershell
cd D:\codex-tasks\cad\official_development_document

powershell -ExecutionPolicy Bypass -File .\tools\extract_chm.ps1
py -3 .\tools\build_manifest.py
py -3 .\tools\build_core_symbols.py
py -3 .\tools\build_task_cards.py
py -3 .\tools\build_on_demand_index.py
py -3 .\tools\validate_doc_system.py

py -3 .\tools\build_task_cards.py

py -3 .\tools\search_cad_help.py task_id CAD2021-TASK-005
py -3 .\tools\search_cad_help.py function switch_to_layout
py -3 .\tools\search_cad_help.py module cad/system/CAD_core.py
py -3 .\tools\search_cad_help.py task "switch target layout"
py -3 .\tools\search_cad_help.py symbol SendCommand
py -3 .\tools\search_cad_help.py symbol TILEMODE
py -3 .\tools\search_cad_help.py symbol 3d_point
py -3 .\tools\search_cad_help.py keyword "title block attribute"
py -3 .\tools\search_cad_help.py task 切换布局
```

## 项目内推荐路径

- 统一连接优先看 `D:/codex-tasks/cad/system/licad.py`
- 布局切换/布局枚举优先看 `D:/codex-tasks/cad/system/CAD_core.py`
- 选择与对象访问优先看 `D:/codex-tasks/cad/system/CAD_selection.py`
- 打印执行链优先看 `D:/codex-tasks/cad/scripts/drawing_basic_service/print/`
- 图签/目录/插块经验优先看 `D:/codex-tasks/cad/scripts/CAD_basic.py`

## 约束

- 先建索引，再扩摘要
- 任务卡是主入口，不按 CHM 原目录组织
- 主索引以 `task_id / symbol / owner / project_function / module_path` 为精确入口
- `aliases_en` 是主要自然语言扩展
- `aliases_zh / keywords_zh` 仅作辅助 alias，不作为主骨架
- 每张任务卡都应补到 `source_topic_ids / source_html_paths / project_refs / rule_refs / reference_dwgs`
- 所有核心卡都要补 pywin32 视角和项目推荐路径
- 与当前目标弱相关的 CHM 页面默认只做轻量索引
