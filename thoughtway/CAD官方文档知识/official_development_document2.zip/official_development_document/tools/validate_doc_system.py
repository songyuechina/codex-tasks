from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
WORKSPACE_ROOT = ROOT.parent.parent
TASK_INDEX_PATH = ROOT / "04_task_cards" / "task_index.json"
TASK_MAP_PATH = ROOT / "07_validation" / "task_to_existing_code_map.json"
TOPIC_PATH_MAP_PATH = ROOT / "06_on_demand_index" / "topic_path_map.json"
MANIFEST_PATH = ROOT / "02_manifest" / "page_manifest.jsonl"


def load_json(path: Path) -> Any:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def resolve_rel(rel_path: str) -> Path | None:
    if not rel_path:
        return None
    doc_path = ROOT / rel_path
    if doc_path.exists():
        return doc_path
    workspace_path = WORKSPACE_ROOT / rel_path
    if workspace_path.exists():
        return workspace_path
    return None


def rel_exists(rel_path: str) -> bool:
    return resolve_rel(rel_path) is not None


def core_meta_index() -> dict[str, dict[str, Any]]:
    result = {}
    for meta_path in (ROOT / "03_core_symbols").rglob("*.meta.json"):
        payload = load_json(meta_path)
        if isinstance(payload, dict) and payload.get("symbol"):
            result[str(payload["symbol"])] = payload
    return result


def function_exists(module_rel: str, function_name: str) -> bool:
    module_path = resolve_rel(module_rel)
    if module_path is None:
        return False
    text = module_path.read_text(encoding="utf-8", errors="ignore")
    patterns = [
        rf"^\s*def\s+{re.escape(function_name)}\s*\(",
        rf"^\s*class\s+{re.escape(function_name)}\b",
        rf"\b{re.escape(function_name)}\b",
    ]
    return any(re.search(pattern, text, flags=re.MULTILINE) for pattern in patterns)


def main() -> None:
    fatal: list[str] = []
    warning: list[str] = []
    gap: list[str] = []

    task_index = load_json(TASK_INDEX_PATH)
    task_map = load_json(TASK_MAP_PATH)
    topic_map = load_json(TOPIC_PATH_MAP_PATH)
    manifest_rows = load_jsonl(MANIFEST_PATH)
    manifest_topic_ids = {str(row.get("topic_id", "")) for row in manifest_rows if row.get("topic_id")}
    core_index = core_meta_index()

    tasks = task_index.get("tasks", []) if isinstance(task_index, dict) else []
    if not isinstance(tasks, list):
        fatal.append("task_index.json tasks is not a list")
        tasks = []

    task_ids = {str(task.get("task_id", "")) for task in tasks if isinstance(task, dict)}
    task_slugs = {str(task.get("slug", "")) for task in tasks if isinstance(task, dict)}
    required_fields = {"task_id", "slug", "path", "symbols", "owners", "project_functions", "module_paths", "aliases_en"}

    for task in tasks:
        if not isinstance(task, dict):
            fatal.append("task_index contains non-dict task payload")
            continue
        missing = sorted(field for field in required_fields if not task.get(field))
        if missing:
            fatal.append(f"{task.get('task_id', '<unknown>')} missing fields: {', '.join(missing)}")
            continue

        task_path = resolve_rel(str(task["path"]))
        if task_path is None:
            fatal.append(f"{task['task_id']} task card missing: {task['path']}")
        else:
            text = task_path.read_text(encoding="utf-8", errors="ignore")
            if str(task["task_id"]) not in text:
                warning.append(f"{task['task_id']} markdown missing inline task_id marker")

        for field in ["module_paths", "project_refs", "rule_refs", "reference_dwgs", "source_html_paths"]:
            for rel_path in task.get(field, []):
                if not rel_exists(str(rel_path)):
                    fatal.append(f"{task['task_id']} missing path in {field}: {rel_path}")

        for symbol in task.get("symbols", []):
            if symbol not in core_index:
                fatal.append(f"{task['task_id']} references missing core symbol: {symbol}")

        implementation_entries = task.get("implementation_entries", [])
        if isinstance(implementation_entries, list):
            for entry in implementation_entries:
                if not isinstance(entry, dict):
                    continue
                module_path = str(entry.get("module_path", ""))
                function_name = str(entry.get("project_function", ""))
                if not rel_exists(module_path):
                    fatal.append(f"{task['task_id']} implementation module missing: {module_path}")
                elif function_name and not function_exists(module_path, function_name):
                    fatal.append(f"{task['task_id']} function not found: {function_name} in {module_path}")

        for topic_id in task.get("source_topic_ids", []):
            if topic_id not in manifest_topic_ids and topic_id not in topic_map:
                warning.append(f"{task['task_id']} unresolved source_topic_id: {topic_id}")

    if isinstance(task_map, dict):
        for task_id, payload in task_map.items():
            if task_id not in task_ids:
                fatal.append(f"task_to_existing_code_map has unknown task_id: {task_id}")
            if isinstance(payload, dict) and payload.get("path") and not rel_exists(str(payload["path"])):
                fatal.append(f"task map path missing for {task_id}: {payload['path']}")

    for symbol, meta in core_index.items():
        path_md = str(meta.get("path_md", ""))
        if not rel_exists(path_md):
            fatal.append(f"core symbol markdown missing for {symbol}: {path_md}")
        for rel_path in meta.get("project_refs", []):
            if not rel_exists(str(rel_path)):
                fatal.append(f"{symbol} missing project_ref path: {rel_path}")
        for rel_path in meta.get("rule_refs", []):
            if not rel_exists(str(rel_path)):
                fatal.append(f"{symbol} missing rule_ref path: {rel_path}")
        for rel_path in meta.get("source_html_paths", []):
            if not rel_exists(str(rel_path)):
                fatal.append(f"{symbol} missing source_html_path: {rel_path}")
        for topic_id in meta.get("source_topic_ids", []):
            if topic_id not in manifest_topic_ids and topic_id not in topic_map:
                warning.append(f"{symbol} unresolved source_topic_id: {topic_id}")
        for related_task in meta.get("related_tasks", []):
            if related_task not in task_ids and related_task not in task_slugs:
                warning.append(f"{symbol} related_task not found: {related_task}")

    system_variable_count = sum(1 for meta in core_index.values() if meta.get("kind") == "system_variable")
    type_topic_count = sum(1 for meta in core_index.values() if meta.get("kind") == "type_topic")
    task_referenced_missing = sorted(
        {
            symbol
            for task in tasks
            if isinstance(task, dict)
            for symbol in task.get("symbols", [])
            if symbol not in core_index
        }
    )

    checks = {
        "manifest_pages": len(manifest_rows),
        "core_symbol_cards": sum(1 for _ in (ROOT / "03_core_symbols").rglob("*.md")),
        "task_cards": sum(1 for _ in (ROOT / "04_task_cards").rglob("*.md")),
        "bridge_docs": sum(1 for _ in (ROOT / "05_pywin32_bridge").rglob("*.md")),
        "task_index_entries": len(tasks),
        "system_variables": system_variable_count,
        "types_and_variants": type_topic_count,
        "task_referenced_symbols_missing_from_core": task_referenced_missing,
    }

    if system_variable_count == 0:
        fatal.append("system_variables still empty")
    if type_topic_count == 0:
        fatal.append("types_and_variants still empty")
    if not core_index:
        fatal.append("no core symbol meta found")

    print(json.dumps(checks, ensure_ascii=False, indent=2))
    if fatal:
        print("Fatal:")
        for item in fatal:
            print(f"- {item}")
    if warning:
        print("Warning:")
        for item in warning:
            print(f"- {item}")
    if gap:
        print("Gap:")
        for item in gap:
            print(f"- {item}")

    if fatal:
        raise SystemExit(1)
    print("Validation passed.")


if __name__ == "__main__":
    main()
